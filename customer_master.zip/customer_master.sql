-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 09, 2022 at 08:47 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `customer_master`
--

-- --------------------------------------------------------

--
-- Table structure for table `signup_master`
--

CREATE TABLE `signup_master` (
  `Username` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `S_code` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signup_master`
--

INSERT INTO `signup_master` (`Username`, `Email`, `S_code`) VALUES
('Ayush kumar', 'ayushsoni5321@gmail.com', 123456),
('Gourav Goswami', 'souravgoswami421@gmail.com', 543210),
('Shubham kumar', 'Skashyap5321@gmail.com', 333333);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `signup_master`
--
ALTER TABLE `signup_master`
  ADD PRIMARY KEY (`Username`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
